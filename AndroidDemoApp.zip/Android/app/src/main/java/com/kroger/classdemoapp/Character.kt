package com.kroger.classdemoapp

data class Character(
    val name: String,
    val power: String,
    val image: Int,
    val detail: String,
)

